from fastapi import FastAPI, Query
import random
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],             # Allow all domains to access your API
    allow_credentials=True,          # Allow cookies and auth headers
    allow_methods=["*"],             # Allow all HTTP methods (GET, POST, etc.)
    allow_headers=["*"],             # Allow all headers in requests
)
flights = [ 
    {"from": "pune", "to": "mumbai", "flight_id": "Airbus  A350 1285 M"},
    {"from": "pune", "to": "delhi", "flight_id": "Airbus  A330 145 MH"},
    {"from": "pune", "to": "bangalore", "flight_id": "Airbus  A330 122 Y"},
    {"from": "pune", "to": "delhi", "flight_id": "Boeing 737 125 UT"},
    {"from": "delhi", "to": "pune", "flight_id": "Airbus  A350 5685 DF"},
    {"from": "delhi", "to": "mumbai", "flight_id": "Airbus  A330 7390 R"},
    {"from": "bangalore", "to": "delhi", "flight_id": "Boeing 737 765 ES"},
    {"from": "mumbai", "to": "delhi", "flight_id": "Airbus  A330 154 TR"},
    {"from": "pune", "to": "mumbai", "flight_id": "Airbus  A330 128 IK"},
    {"from": "pune", "to": "delhi", "flight_id": "Airbus  A350 152 MG"},
    {"from": "pune", "to": "bangalore", "flight_id": "Airbus  A330 120 JL"},
    {"from": "pune", "to": "delhi", "flight_id": "Boeing 737 190 HK"},
    {"from": "delhi", "to": "pune", "flight_id": "Airbus  A330 1337 VB"},
    {"from": "delhi", "to": "mumbai", "flight_id": "Airbus  A330 098 XE"},
    {"from": "bangalore", "to": "delhi", "flight_id": "Airbus  A330 034 LM"},
    {"from": "mumbai", "to": "pune", "flight_id": "Airbus  A350 239 ZY"},
    {"from": "mumbai", "to": "pune", "flight_id": "Airbus  A330 190 KS"},
    {"from": "mumbai", "to": "delhi", "flight_id": "Airbus  A330 856 WP"},
    {"from": "mumbai", "to": "pune", "flight_id": "Boeing 737 3509 DZ"},
]

status_options = [
    "On Time",
    "Delayed by 30 mins",
    "Delayed by 1 hr",
    "Delayed by 2 hrs",
    "Delayed by 3 hrs",
]

flights_details = [
    {"from": "pune", "to": "mumbai", "time": "02:00", "st": "pm", "flight_id": "Airbus  A350 1285 M", 'cost': 3999},
    {"from": "pune", "to": "delhi", "time": "03:00", "st": "am", "flight_id": "Airbus  A330 145 MH", 'cost': 3999},
    {"from": "pune", "to": "bangalore", "time": "04:00", "st": "pm", "flight_id": "Airbus  A330 122 Y", 'cost': 3999},
    {"from": "pune", "to": "delhi", "time": "05:00", "st": "pm", "flight_id": "Boeing 737 125 UT", 'cost': 3999},
    {"from": "delhi", "to": "pune", "time": "02:00", "st": "am", "flight_id": "Airbus  A350 5685 DF", 'cost': 3999},
    {"from": "delhi", "to": "mumbai", "time": "10:00", "st": "am", "flight_id": "Airbus  A330 7390 R", 'cost': 3999},
    {"from": "bangalore", "to": "delhi", "time": "01:00", "st": "pm", "flight_id": "Boeing 737 765 ES", 'cost': 3999},
    {"from": "mumbai", "to": "delhi", "time": "09:00", "st": "am", "flight_id": "Airbus  A330 154 TR", 'cost': 3999},
    {"from": "pune", "to": "mumbai", "time": "05:00", "st": "pm", "flight_id": "Airbus  A330 128 IK", 'cost': 3999},
    {"from": "pune", "to": "delhi", "time": "10:00", "st": "am", "flight_id": "Airbus  A350 152 MG", 'cost': 3999},
    {"from": "pune", "to": "bangalore", "time": "05:00", "st": "am", "flight_id": "Airbus  A330 120 JL", 'cost': 3999},
    {"from": "pune", "to": "delhi", "time": "06:00", "st": "pm", "flight_id": "Boeing 737 190 HK", 'cost': 3999},
    {"from": "delhi", "to": "pune", "time": "07:00", "st": "am", "flight_id": "Airbus  A330 1337 VB", 'cost': 3999},
    {"from": "delhi", "to": "mumbai", "time": "01:00", "st": "am", "flight_id": "Airbus  A330 098 XE", 'cost': 3999},
    {"from": "bangalore", "to": "delhi", "time": "11:00", "st": "pm", "flight_id": "Airbus  A330 034 LM", 'cost': 3999},
    {"from": "mumbai", "to": "pune", "time": "06:00", "st": "am", "flight_id": "Airbus  A350 239 ZY", 'cost': 3999},
    {"from": "mumbai", "to": "pune", "time": "11:00", "st": "am", "flight_id": "Airbus  A330 190 KS", 'cost': 3999},
    {"from": "mumbai", "to": "delhi", "time": "03:00", "st": "pm", "flight_id": "Airbus  A330 856 WP", 'cost': 3999},
    {"from": "mumbai", "to": "pune", "time": "10:00", "st": "pm", "flight_id": "Boeing 737 3509 DZ", 'cost': 3999},
    ]

flight_ids = ['Airbus  A350 1285 M', 'Airbus  A330 145 MH', 'Airbus  A330 122 Y', 'Boeing 737 125 UT',
              'Airbus  A350 5685 DF', 'Airbus  A330 7390 R', 'Boeing 737 765 ES', 'Airbus  A330 154 TR',
              'Airbus  A330 128 IK', 'Airbus  A350 152 MG', 'Airbus  A330 120 JL', 'Boeing 737 190 HK',
              'Airbus  A330 1337 VB', 'Airbus  A330 098 XE', 'Airbus  A330 034 LM', 'Airbus  A350 239 ZY',
              'Airbus  A330 190 KS', 'Airbus  A330 856 WP', 'Boeing 737 3509 DZ']

@app.get("/stats")
def statsbar():
    flights : int = random.randint(2000,9999)
    people : int = random.randint(10000,99999)
    cities :  int = random.randint(20,29)
    performance  : int = random.randint(70,95)
    return {
        "flights": flights,
        "people": people,
        "cities": cities,
        "performance":performance
    }

@app.get("/status")
def status():
    n : int = random.randint(0,7)
    selected = random.sample(flights,n)
    for i in selected:
        i["status"] = random.choice(status_options)
    return selected


@app.get("/searchflights")
def searchFlights(
    from_: str = Query(..., alias="from_"),
    to: str = Query(...),
    time: str = Query(...)
):
    from_city = from_.lower()
    to_city = to.lower()
    slot = time.lower().split()[1]

    results = [
        i for i in flights_details
        if i["from"] == from_city and i["to"] == to_city and i["st"] == slot
    ]
    return results

@app.get("/flightstatus")
def flightStatus(Id : str):
    for i in flights:
        if i["flight_id"] == Id:
            i["status"] = random.choice(status_options)
            return i
    return {"message" : "No Such Flight Exists. Please Enter Valid Flight Id. Only Todays Flight Status Can be checked"}

@app.get("/bookingflight")
def searchFlights(
    from_: str = Query(..., alias="from_"),
    to: str = Query(...),
):
    from_city = from_.lower()
    to_city = to.lower()

    results = [
        i for i in flights_details
        if i["from"] == from_city and i["to"] == to_city 
    ]
    return results